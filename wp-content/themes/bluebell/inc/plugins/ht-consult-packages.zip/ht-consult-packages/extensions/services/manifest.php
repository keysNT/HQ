<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = esc_html__( 'Services', 'consult' );
$manifest['description'] = esc_html__(
	'A beautiful and professional way to showcase your services or products on your website.',
	'consult'
);
$manifest['version'] = '1.0';
$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-server';
