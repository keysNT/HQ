<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

class FW_Extension_Testimonial extends FW_Extension {
  private $post_type = 'ht-testimonial';
  private $post_type_slug = 'testimonials';

  public function _init(){
	$this->define_slugs();
	  if ( is_admin() ) {
		  $this->add_admin_filters();
	  }

    add_action( 'init', array( $this, 'consult_action_register_post_type' ) );

  }

  private function define_slugs(){
    $this->slug = apply_filters( 'consult_testimonial_slug', $this->post_type_slug );
  }

	public function add_admin_filters() {

		add_filter( 'fw_post_options', array( $this, '_filter_admin_add_post_options' ), 10, 2 );
	}

  public function consult_action_register_post_type() {
    $post_names = apply_filters( 'fw_ext_testimonial_post_type_name',
			array(
				'singular' => __( 'Testimonial', 'consult' ),
				'plural'   => __( 'Testimonials', 'consult' )
			) );

		register_post_type( $this->post_type,
			array(
				'labels'             => array(
					'name'               => $post_names['plural'], //__( 'Portfolio', 'consult' ),
					'singular_name'      => $post_names['singular'], //__( 'Portfolio project', 'consult' ),
					'add_new'            => __( 'Add New', 'consult' ),
					'add_new_item'       => sprintf( __( 'Add New %s', 'consult' ), $post_names['singular'] ),
					'edit'               => __( 'Edit', 'consult' ),
					'edit_item'          => sprintf( __( 'Edit %s', 'consult' ), $post_names['singular'] ),
					'new_item'           => sprintf( __( 'New %s', 'consult' ), $post_names['singular'] ),
					'all_items'          => sprintf( __( 'All %s', 'consult' ), $post_names['plural'] ),
					'view'               => sprintf( __( 'View %s', 'consult' ), $post_names['singular'] ),
					'view_item'          => sprintf( __( 'View %s', 'consult' ), $post_names['singular'] ),
					'search_items'       => sprintf( __( 'Search %s', 'consult' ), $post_names['plural'] ),
					'not_found'          => sprintf( __( 'No %s Found', 'consult' ), $post_names['plural'] ),
					'not_found_in_trash' => sprintf( __( 'No %s Found In Trash', 'consult' ), $post_names['plural'] ),
					'parent_item_colon'  => '' /* text for parent types */
				),
				'description'        => __( 'Create a testimonial item', 'consult' ),
				'public'             => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'show_in_nav_menus' 	=> true,
				'publicly_queryable' => true,
				/* queries can be performed on the front end */
				'has_archive'        => true,
				'rewrite'            => array(
					'slug' => $this->slug
				),
				'menu_position'      => 4,
				'show_in_nav_menus'  => true,
				'menu_icon'          => 'dashicons-format-quote',
				'hierarchical'       => false,
				'query_var'          => true,
				/* Sets the query_var key for this post type. Default: true - set to $post_type */
				'supports'           => array(
					'title', /* Text input field to create a post title. */
					'editor',
					'thumbnail', /* Displays a box for featured image. */
				),
				'capabilities'       => array(
					'edit_post'              => 'edit_pages',
					'read_post'              => 'edit_pages',
					'delete_post'            => 'edit_pages',
					'edit_posts'             => 'edit_pages',
					'edit_others_posts'      => 'edit_pages',
					'publish_posts'          => 'edit_pages',
					'read_private_posts'     => 'edit_pages',
					'read'                   => 'edit_pages',
					'delete_posts'           => 'edit_pages',
					'delete_private_posts'   => 'edit_pages',
					'delete_published_posts' => 'edit_pages',
					'delete_others_posts'    => 'edit_pages',
					'edit_private_posts'     => 'edit_pages',
					'edit_published_posts'   => 'edit_pages',
				),
			) );
  }

	/**
	 * @internal
	 *
	 * @param array $options
	 * @param string $post_type
	 *
	 * @return array
	 */
	public function _filter_admin_add_post_options( $options, $post_type ) {
		if ( $post_type === $this->post_type ) {
			$options[] = array(
				$this->get_options('posts/'.$post_type, $options = array())
			);
		}


		return $options;
	}

	public function get_post_type_name() {
		return $this->post_type;
	}


}
