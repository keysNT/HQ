<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = esc_html__( 'Testimonial', 'consult' );
$manifest['description'] = esc_html__(
	'Testimonials is a extension to display testimonials, reviews or quotes in multiple ways! Fully compatible with the brand new WordPress.',
	'consult'
);
$manifest['version'] = '1.0';

$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-commenting';
