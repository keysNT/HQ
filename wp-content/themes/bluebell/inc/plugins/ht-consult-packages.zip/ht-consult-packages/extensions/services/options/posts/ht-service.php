<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package consult
 */

$options = array(
    'metabox' => array(
        'type'     => 'box',
        'title'    => esc_html__( 'Service Settings', 'consult' ),
        'options'  => array(
            'consult_icon'  => array(
                'type'  => 'icon-v2',
                'label'   => esc_html__( 'Icon', 'consult' ),
                'desc'    => esc_html__( 'Choose an Icon', 'consult' ),
                'modal_size' => 'large',
                'preview_size' => 'sauron',
            ),
        )

    )
);