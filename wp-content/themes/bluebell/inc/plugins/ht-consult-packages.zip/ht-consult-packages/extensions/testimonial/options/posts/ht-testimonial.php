<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package consult
 */

$options = array(
    'metabox' => array(
        'type'     => 'box',
        'title'    => esc_html__( 'Testimonial Settings', 'consult' ),
        'priority' => 'high',
        'options'  => array(
            'name'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Name / Company', 'consult' ),
            ),
            'position'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Position', 'consult' ),
            )
        )

    )
);