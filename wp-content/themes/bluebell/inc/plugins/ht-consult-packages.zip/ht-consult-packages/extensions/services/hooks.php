<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * [check if there are defined views for course template]
 * @param  [string] $template
 * @return [string]
 */
function _filter_fw_ext_service_template_include($template){
	/**
	 * FW_Extension_Recipe_Portfolio
	 * @var $service
	 */
	$service = fw()->extensions->get('services');
	if(is_singular($service->get_post_type_name())){
			$template = fw_locate_theme_path('/page.php');
	}else if (is_tax($service->get_taxonomy_name()) && $service->locate_view_path('taxonomy')){
		return $service->locate_view_path('taxonomy');
	}

	return $template;
}

add_filter('template_include', '_filter_fw_ext_service_template_include');
