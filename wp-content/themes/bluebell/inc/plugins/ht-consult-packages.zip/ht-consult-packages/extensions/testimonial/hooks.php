<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * [check if there are defined views for course template]
 * @param  [string] $template
 * @return [string]
 */
function _filter_fw_ext_testimonial_template_include($template){
	/**
	 * FW_Extension_Recipe_Portfolio
	 * @var $testimonial
	 */
	$testimonial = fw()->extensions->get('ht-testimonial');
	if(is_singular($testimonial->get_post_type_name())){
			$template = fw_locate_theme_path('/page.php');
	}else if (is_tax($testimonial->get_taxonomy_name()) && $testimonial->locate_view_path('taxonomy')){
		return $testimonial->locate_view_path('taxonomy');
	}

	return $template;
}

//add_filter('template_include', '_filter_fw_ext_testimonial_template_include');
