<?php
/**
 * Plugin Name: HT Job
 * Plugin URI: http://haintheme.com
 * Description: Create a Job in your theme.
 * Version: 1.0
 * Author: Haintheme
 * Author URI: http://haintheme.com
 * Text Domain: consult
 * License: GNU General Public License v2 or later
 */



function ht_job(){
	$labels = array(
		'name'               => esc_html__( 'HT Job', 'consult' ),
		'singular_name'      => esc_html__( 'HT Job', 'consult' ),
		'menu_name'          => esc_html__( 'HT Job', 'consult' ),
		'name_admin_bar'     => esc_html__( 'HT Job', 'consult' ),
		'add_new'            => esc_html__( 'Add New', 'consult' ),
		'add_new_item'       => esc_html__( 'Add New Job', 'consult' ),
		'new_item'           => esc_html__( 'New Job', 'consult' ),
		'edit_item'          => esc_html__( 'Edit Job', 'consult' ),
		'view_item'          => esc_html__( 'View Job', 'consult' ),
		'all_items'          => esc_html__( 'All Job', 'consult' ),
		'search_items'       => esc_html__( 'Search Job', 'consult' ),
		'parent_item_colon'  => esc_html__( 'Parent Job:', 'consult' ),
		'not_found'          => esc_html__( 'No Job found.', 'consult' ),
		'not_found_in_trash' => esc_html__( 'No Job found in Trash.', 'consult' )
	);
	$args = array(
		'labels'             => $labels,
		'menu_icon'			 => 'dashicons-megaphone',
		'menu_position'		 => 4,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'ht-job' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt')
	);
	register_post_type( 'job', $args );
	/* job cat */
	$labels = array(
		'name'              => esc_html__( 'Categories', 'consult' ),
		'singular_name'     => esc_html__( 'Category', 'consult' ),
		'search_items'      => esc_html__( 'Search Categories', 'consult' ),
		'all_items'         => esc_html__( 'All Categories', 'consult' ),
		'parent_item'       => esc_html__( 'Parent Category', 'consult' ),
		'parent_item_colon' => esc_html__( 'Parent Category', 'consult' ) . ':',
		'edit_item'         => esc_html__( 'Edit Category', 'consult' ),
		'update_item'       => esc_html__( 'Update Category', 'consult' ),
		'add_new_item'      => esc_html__( 'Add New Category', 'consult' ),
		'new_item_name'     => esc_html__( 'New Category Name', 'consult' ),
		'menu_name'         => esc_html__( 'Category', 'consult' ),
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'job-cat' ),
	);
	register_taxonomy( 'ht-job-cat', array( 'job' ), $args );


}
add_action( 'init', 'ht_job' );